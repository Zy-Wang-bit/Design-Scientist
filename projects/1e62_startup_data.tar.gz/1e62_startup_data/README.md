# 1E62 pH-Sensitive Antibody Design Startup Data

This directory contains the startup data for a new Design Scientist project on
1E62 antibody pH-sensitive binding.

## Task

Design 1E62 antibody variants that retain binding at pH 7.4 and reduce binding
or promote dissociation at pH 6.0.

## Included Data

- `raw/base_sequences/`: WT antibody and antigen genotype sequences.
- `raw/base_structures_optional/`: optional WT/base structural models.
- `raw/wet_lab/ae_kd_ratio.csv`: Ae-type `KD_ratio` wet-lab endpoint.
- `raw/wet_lab/elisa_dilution_measurements.csv`: long-form ELISA measurements
  for Ae, B, and D1 across pH, concentration, and replicate.
- `raw/wet_lab/elisa_summary.csv`: wet-lab ELISA summary with computed design
  score columns removed.
- `raw/wet_lab/expression.csv`: expression and concentration feasibility data.
- `raw/wet_lab/variant_sequences.csv`: sequence provenance for tested variants.

## Evidence Notes

- `KD_ratio` is Ae-specific evidence.
- ELISA data provide Ae, B, and D1 measurements at pH 6.0 and pH 7.4.
- Startup CSV files use single-row explicit headers; multi-row plate headers
  have already been converted to canonical columns.
- Expression data should be treated as feasibility or QC evidence.
- Variant sequence data should be used as provenance for tested variants.
- No untested or framework-designed variants are included.

Before running design or panel selection, run a schema audit and produce
standardized tables from the allowlisted files in `data_contract.yaml`.
